geth --rinkeby --rpc --rpcapi="personal,eth,network,web3,net" --ipcpath "~/.ethereum/geth.ipc"
